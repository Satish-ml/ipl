package com.example.MyFirstApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
